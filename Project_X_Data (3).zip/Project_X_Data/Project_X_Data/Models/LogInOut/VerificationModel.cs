﻿namespace Project_X_Data.Models.LogInOut
{
    public class VerificationModel
    {
        public string Email { get; set; }
        public string Code { get; set; }
    }
}
