﻿namespace Project_X_Data.Models.LogInOut
{
    public class GmailFormModel
    {
        public string ToEmail { get; set; }
        public string Subject { get; set; }
        public string Message { get; set; }
    }
}
